/*
 * dummy C program to test 'ctags'
 */
main()
{ ; }
thing1()
{ ; }
thing2()
{ ; }
eggs()
{ ; }
ham()
{ ; }

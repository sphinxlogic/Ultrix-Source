'\"	SCCSID: @(#)tmac.m	3.0	4/22/86
'\"	(SYSTEM 5.0)	tmac.m	1.2
.if n .so /usr/lib/macros/mmn
.if t .so /usr/lib/macros/mmt

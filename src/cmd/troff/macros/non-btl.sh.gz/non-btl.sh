
#	SCCSID: @(#)non-btl.sh	3.0	4/22/86
#	Empty shell script, can't find out why it's here.
#	save it just in case.


/**********************************************************************
 *   Copyright (c) Digital Equipment Corporation 1984, 1985, 1986.    *
 *   All Rights Reserved. 					      *
 *   Reference "/usr/src/COPYRIGHT" for applicable restrictions.      *
 **********************************************************************/

/* SCCSID: @(#)had.h	3.0	4/22/86 */
# define HADA had[('a'-'a')]
# define HADB had[('b'-'a')]
# define HADC had[('c'-'a')]
# define HADD had[('d'-'a')]
# define HADE had[('e'-'a')]
# define HADF had[('f'-'a')]
# define HADG had[('g'-'a')]
# define HADH had[('h'-'a')]
# define HADI had[('i'-'a')]
# define HADJ had[('j'-'a')]
# define HADK had[('k'-'a')]
# define HADL had[('l'-'a')]
# define HADM had[('m'-'a')]
# define HADN had[('n'-'a')]
# define HADO had[('o'-'a')]
# define HADP had[('p'-'a')]
# define HADQ had[('q'-'a')]
# define HADR had[('r'-'a')]
# define HADS had[('s'-'a')]
# define HADT had[('t'-'a')]
# define HADU had[('u'-'a')]
# define HADV had[('v'-'a')]
# define HADW had[('w'-'a')]
# define HADX had[('x'-'a')]
# define HADY had[('y'-'a')]
# define HADZ had[('z'-'a')]

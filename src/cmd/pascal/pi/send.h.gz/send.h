
/**********************************************************************
 *   Copyright (c) Digital Equipment Corporation 1984, 1985, 1986.    *
 *   All Rights Reserved. 					      *
 *   Reference "/usr/src/COPYRIGHT" for applicable restrictions.      *
 **********************************************************************/

/*	SCCSID: @(#)send.h	3.0	4/22/86 */
/* Copyright (c) 1979 Regents of the University of California */

#define	RINIT	1
#define	RENQ	2
#define	RTREE	3
#define	RTRFREE	4
#define	RTRCHK	5
#define	REVENIT	6
#define	RSTRING	7
#define	REVLAB	8
#define	REVCNST	9
#define	REVTBEG	10
#define	REVTYPE	11
#define	REVTEND	12
#define	REVVBEG	13
#define	REVVAR	14
#define	REVVEND	15
#define	REVFHDR	16
#define	REVFFWD	17
#define	REVFBDY	18
#define	REVFEND	19
#define	ROPUSH	20
#define	ROPOP	21
#define	ROSET	22
#define	RKILL	23
#define	RFINISH	24

#define	RLAST	24

extern	char *trdesc[];

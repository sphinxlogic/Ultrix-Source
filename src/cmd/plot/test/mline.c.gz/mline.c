
/**********************************************************************
 *   Copyright (c) Digital Equipment Corporation 1984, 1985, 1986.    *
 *   All Rights Reserved. 					      *
 *   Reference "/usr/src/COPYRIGHT" for applicable restrictions.      *
 **********************************************************************/

/* SCCSID: @(#)mline.c	3.0	4/22/86 */
/* Plot test program */
/* BULL's Eye */
main()
{
int i;
openpl();
line(0,0,512,0);
closepl();
}

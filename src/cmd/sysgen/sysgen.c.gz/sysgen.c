static char Sccsid[] = "@(#)sysgen.c	3.0	4/22/86";
/*
 * NO LONGER USED
 */

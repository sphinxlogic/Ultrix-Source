
/**********************************************************************
 *   Copyright (c) Digital Equipment Corporation 1984, 1985, 1986.    *
 *   All Rights Reserved. 					      *
 *   Reference "/usr/src/COPYRIGHT" for applicable restrictions.      *
 **********************************************************************/

#
/*
 * SCCSID: @(#)rcv.h	3.0 4/22/86
 */

/*
 * Mail -- a mail program
 *
 * This file is included by normal files which want both
 * globals and declarations.
 */

/*
 * Based on
 *	Sccs Id = "@(#)rcv.h	2.2 10/21/82";
 */

#ifdef	pdp11
#include <whoami.h>
#endif
#include "def.h"
#include "glob.h"

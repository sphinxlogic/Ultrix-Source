
/**********************************************************************
 *   Copyright (c) Digital Equipment Corporation 1984, 1985, 1986.    *
 *   All Rights Reserved. 					      *
 *   Reference "/usr/src/COPYRIGHT" for applicable restrictions.      *
 **********************************************************************/

/*
 * Just keep track of the date/sid of this version of Mail.
 * Load this file first to get a "total" Mail version.
 */

/*
 * Based on
 *	static	char	*SccsID = "@(#)UCB Mail Version 2.18 (5/19/83)";
 *	char	*version = "2.18 5/19/83";
 */

static char *Sccsid = "@(#)Mail Version 3.0 (4/22/86)";
char	*version = "3.0 4/22/86";

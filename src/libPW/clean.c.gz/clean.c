
/**********************************************************************
 *   Copyright (c) Digital Equipment Corporation 1984, 1985, 1986.    *
 *   All Rights Reserved. 					      *
 *   Reference "/usr/src/COPYRIGHT" for applicable restrictions.      *
 **********************************************************************/

static char Sccsid[]="@(#)clean.c 3.0 4/22/86";
/*
	Default clean_up routine for fatal and setsig.
	User defined clean_up routines are used for removing
	temporary files, etc.
*/

clean_up()
{
}

char version[] = "Version 4.65 Fri Oct 9 11:07:55 EDT 1987";

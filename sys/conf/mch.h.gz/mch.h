
#define HTDUMP 1
#define TSDUMP 0
#define TMDUMP 0
#define TKDUMP 0
#define RLDUMP 0
#define HKDUMP 0
#define RPDUMP 0
#define HPDUMP 0
#define RADUMP 0
#define RXDUMP 0

HTCS1 = 172440

HT_BMAJ = 8

#define FPP	1

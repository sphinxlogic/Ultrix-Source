
/**********************************************************************
 *   Copyright (c) Digital Equipment Corporation 1984, 1985, 1986.    *
 *   All Rights Reserved. 					      *
 *   Reference "/usr/src/COPYRIGHT" for applicable restrictions.      *
 **********************************************************************/

/*
 * SCCSID: @(#)syslocal.c	3.0	4/21/86
 */

/*
 * This file is set aside for the customer to
 * put his own system calls into.
 */
#include <sys/param.h>
